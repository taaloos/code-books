// Non-Mozilla Browsers:
strongElem.innerText

// All platforms:
strongElem.firstChild.nodeValue
