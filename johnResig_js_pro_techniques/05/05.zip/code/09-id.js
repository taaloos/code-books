function id(name) {
    return document.getElementById(name);
}
