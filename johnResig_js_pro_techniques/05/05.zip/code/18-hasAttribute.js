function hasAttribute( elem, name ) {
    return elem.getAttribute(name) != null;
}
