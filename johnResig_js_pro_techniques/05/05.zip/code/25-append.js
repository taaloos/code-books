function append( parent, elem ) {
    parent.appendChild( checkElem( elem ) );
}
