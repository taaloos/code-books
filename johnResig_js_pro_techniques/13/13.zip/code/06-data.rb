rows.columns = [“title”,”author”,”content”,”date”]

rows = [
    [“HomePage”,”John”,”Welcome to my wonderful wiki!”,”20060324122514”],
    [“Test”,”Anonymous”,”Lorem ipsum dolem…”,”20060321101345”],
    …
]
