// Submit the query to the server 
$.post( apiURL, { db: db, sql: q }, function(j) {
      // Handle the Response from the server
});
