// Add a mouseover event listener to the element that has an
// ID of 'body'
YAHOO.util.Event.addListener('body','mouseover',function(){

    // and change the background color of the element to red
    this.style.backgroundColor = 'red';

});

