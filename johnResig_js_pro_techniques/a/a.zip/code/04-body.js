// Change the margins of the <body>
document.body.style.margin = “0px”;

// document.body is equivalent to:
document.getElementsByTagName(“body”)[0]
