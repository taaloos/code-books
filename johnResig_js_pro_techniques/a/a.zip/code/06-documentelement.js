// Find the documentElement, to find an Element by ID
someRandomNode.documentElement.getElementById(“body”)
