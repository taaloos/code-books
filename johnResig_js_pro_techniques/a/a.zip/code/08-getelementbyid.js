// Find the Element with an ID of body
document.getElementById(“body”)

// Hide the Element with an ID of notice
document.getElementById(“notice”).style.display = ‘none’;
