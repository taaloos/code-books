// Locate the element with the ID of ‘body’
document.getElementById(“body”)

// Locate all the elements with the tag name of  <div>.
document.getElementsByTagName(“div”)
