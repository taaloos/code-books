// A globally-scope variable, containing the string 'test'
var test = "test";

// You'll notice that our 'global' variable and the the
// property of the the window object are identical
alert( window.test == test );

