defaults write com.apple.Safari IncludeDebugMenu 1
