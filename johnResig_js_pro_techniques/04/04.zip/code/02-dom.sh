defaults write com.apple.Safari WebKitDeveloperExtras -bool true
