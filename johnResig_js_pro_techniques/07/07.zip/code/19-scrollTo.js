// If you wanted to scroll the browser up to the top of the browser, you could do:
window.scrollTo(0,0);

// If you wanted to scroll to the position of a specific element, you could do:
window.scrollTo( 0, pageY( document.getElementById(“body”) ) );

