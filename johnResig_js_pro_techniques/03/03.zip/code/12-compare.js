// Both of these are true
null == false
0 == undefined

// You should use !== or === instead
null !== false
false === false

