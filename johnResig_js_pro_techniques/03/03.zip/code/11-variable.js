// Incorrect variable use
foo = 'bar';

// Correct variable delcaration
var foo;
...
foo = 'bar';

