// This code is legal, normal, Javascript
if ( dog == cat )
if ( cat == mouse )
mouse = "cheese";

// JSLint requires that it be written like this:
if ( dog == cat ) {
    if ( cat == mouse ) {
        mouse = "cheese";
    }
}

