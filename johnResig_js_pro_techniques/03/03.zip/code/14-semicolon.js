// Be sure to include semicolons at the end of all statements, if you plan on
// compressing your Javascript code
var foo = 'bar';
var bar = function(){
    alert('hello');
};
bar();

