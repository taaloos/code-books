// Watch for the user leaving the web site
window.onunload = function(){

    // Display a message to the user, thanking them for visiting
    alert( “Thanks for visiting!” );

}; 
