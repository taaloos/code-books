<?php
 require_once('book_sc_fns.php');
 do_html_header('Administration');

 display_login_form();

 do_html_footer();
?>
