<head>
<title>SuperFastOnlineNews</title>

<style type="text/css">
body {text-align:left;font: 80% arial,verdana,sans-serif}
h1,h2,h3 {color:#993300}
h1 {font-size:150%}
h2 {font-size:135%}
h2 {font-size:120%}

.menu {text-align:left;font: 100% arial,verdana,sans-serif;font-weight:bold;}
.morelink,.footer {text-align:right;font: 65% arial,verdana,sans-serif}
.morelink {color:#993300}
.footer {color:#000000}
.byline {text-align:left;font: 100% arial,verdana,sans-serif;font-weight:bold;}
</style>

</head>
<body>
<table border='0' height='100%' width='100%' cellspacing='0'>
<tr>
  <td bgcolor='orange' colspan='2' height='10' width='100%'>&nbsp;</td>
</tr>
<tr>
  <td valign='top' height='100%' bgcolor='orange'>
    <img src="logo.gif" width='100' height='50'>
    <br />
    <div class = "menu">
    <a href="index.php">Headlines</a>
    <br />
    <br />
    <a href="page.php?page=news">News</a>
    <br />
    <a href="page.php?page=sport">Sport</a>
    <br />
    <a href="page.php?page=weather">Weather</a>
    <br />
    <br />
    <a href="search_form.php">Search</a>
    
    </div>
  </td>
  <td valign='top' width='100%'>
    <p>
    <h1>SuperFastOnlineNews</h1>
