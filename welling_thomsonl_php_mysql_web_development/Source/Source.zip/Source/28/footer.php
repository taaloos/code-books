  </p>
  </td>
</tr>
<tr>
  <td height='20' bgcolor='orange'>&nbsp;</td>
  <td height='20' bgcolor='orange' align='center'>
    <p class='footer'>
      &copy; 2004 - Stories may not be reproduced without permission 
    </p>
  </td>
</tr>
</table>
