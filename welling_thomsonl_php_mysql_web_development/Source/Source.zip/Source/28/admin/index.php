<html>
<head>
<title>Admin Menu</title>
</head>
<body>
<h1>Admin Menu</h1>
<ul>
  <li>Writers - <a href = 'writer.php'>Add/Edit stories</a></li>
  <li>Editors - <a href = 'publish.php'>Publish/Unpublish stories</a></li>
</ul>
</body>
</html>