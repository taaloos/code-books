/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : Ter Mai  6 17:13:18 BRT 2003
    copyright            : (C) 2003 by Andr� Duarte Bueno
    email                : andre@lmpt.ufsc.br
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
	#include <config.h>
#endif

#include <iostream.h>
#include <stdlib.h>

#include "Base/TClassea.h"

int main(int argc, char *argv[])
{
  cout << "Hello, World!" << endl;

  TClasseA obj;
  obj.Run();
  return EXIT_SUCCESS;
}
