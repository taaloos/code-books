/***************************************************************************
                          TClassea.cpp  -  description
                             -------------------
    begin                : Ter Mai 6 2003
    copyright            : (C) 2003 by Andr� Duarte Bueno
    email                : andre@lmpt.ufsc.br
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#include <iostream>
#include "TClassea.h"

TClasseA::TClasseA()	{	}
TClasseA::~TClasseA()	{ }

/** A fun��o Run solicita ao usu�rio o valor de x e mostra o mesmo na tela */
void TClasseA::Run()
{
	std::cout << "Entre com o valor de x:" << std::endl;
	std::cin  >> 	x;
	std::cout << "x = " << x << std::endl;
}

/** Read property of int x. */
const int& TClasseA::getx()
	{
	return x;
	}
