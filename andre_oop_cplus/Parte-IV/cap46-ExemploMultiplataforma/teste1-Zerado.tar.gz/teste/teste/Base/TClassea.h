/***************************************************************************
                          TClassea.h  -  description
                             -------------------
    begin                : Ter Mai 6 2003
    copyright            : (C) 2003 by Andr� Duarte Bueno
    email                : andre@lmpt.ufsc.br
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef TCLASSEA_H
#define TCLASSEA_H


/**Classe exemplo
  *@author Andr� Duarte Bueno
  */

class TClasseA {
public: 
	TClasseA();
	~TClasseA();
  /** A fun��o Run solicita ao usu�rio o valor de x e mostra o mesmo na tela */
  virtual void Run();

  /** Read property of int x. */
  virtual const int& getx();

    /** Set the property of int x. */
  virtual void  setx(int _x) { x = _x; };

public: // Public attributes
  /** Valor de uma vari�vel */
  int x;
};

#endif
